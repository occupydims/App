
package com.example.packtrack.network

import retrofit2.http.Body
import retrofit2.http.Headers
import retrofit2.http.POST
import retrofit2.Call

data class TrackingRequest(val number: String)
data class TrackingResponse(
    val code: String?,
    val status: Int?,
    val data: TrackingData?
)

data class TrackingData(
    val items: List<TrackingItem>?
)

data class TrackingItem(
    val tracking_number: String,
    val carrier_code: String,
    val status: String,
    val origin_info: TrackingOriginInfo?
)

data class TrackingOriginInfo(
    val trackinfo: List<TrackingCheckpoint>?
)

data class TrackingCheckpoint(
    val Date: String?,
    val StatusDescription: String?
)

interface TrackingApiService {
    @Headers("Content-Type: application/json", "17token: mock_api_key")
    @POST("track")
    fun trackPackage(@Body request: Map<String, Any>): Call<TrackingResponse>
}
